package com.tim.sso.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tim.util.MD5Util;


@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String name = req.getParameter("uname");
		String pwd = req.getParameter("pwd");
		String url = req.getParameter("url");
		System.out.println("name:" + name + ",pwd:" + pwd + ",url:" + url);
		String token = createToken(name, pwd);
		if (LoginData.userData.containsKey(name))
		{
			String value = LoginData.userData.get(name);
			if (value != null && value.equals(pwd))
			{
				String reqURL = "http://localhost:8081/sso_01/ssoCheck?token=" + token + "&name=" + name + "&url=" + url;
				resp.sendRedirect(reqURL);
				return;
			}
		}
		req.getRequestDispatcher("/login.jsp").forward(req, resp);
	}

	private String createToken(String name, String pwd)
	{
		String perString = name + pwd;
		return MD5Util.MD5(perString);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		this.doPost(req, resp);
	}
}
