package com.tim.sso.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tim.util.MD5Util;


@WebServlet(urlPatterns = "/ssoCheck")
public class SSOCheckServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String name = req.getParameter("name");
		String token = req.getParameter("token");
		Boolean result = checkToken(name, token);
		resp.getWriter().write(result.toString());
		resp.getWriter().flush();
	}

	private Boolean checkToken(String name, String token)
	{
		if (!LoginData.userData.containsKey(name) || token == null || "".equals(token))
		{
			return false;
		}
		String pwd = LoginData.userData.get(name);
		String currentToken = MD5Util.MD5(name + pwd);
		if (token.equals(currentToken))
		{
			return true;
		}
		return false;
	}

	private String createToken(String name, String pwd)
	{
		String perString = name + pwd;
		return MD5Util.MD5(perString);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		this.doPost(req, resp);
	}
}
