package com.tim.sso.servlet;

import java.util.HashMap;
import java.util.Map;


public class LoginData
{
	public static Map<String, String> userData = new HashMap<String, String>();
	static
	{
		userData.put("t1", "1");
		userData.put("t2", "2");
		userData.put("t3", "3");
		userData.put("t4", "4");
		userData.put("t5", "5");
		userData.put("t6", "6");
		userData.put("t7", "7");
	}
}
