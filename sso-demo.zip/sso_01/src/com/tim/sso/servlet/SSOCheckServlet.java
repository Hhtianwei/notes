package com.tim.sso.servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tim.sso.login.LoginInfo;


public class SSOCheckServlet extends HttpServlet
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String name = req.getParameter("name");
		String token = req.getParameter("token");
		String url = req.getParameter("url");
		HttpSession session = req.getSession();
		LoginInfo loginInfo = new LoginInfo();
		loginInfo.setLoginTime(new Date());
		loginInfo.setToken(token);
		loginInfo.setUserName(name);

		//sso 登录成功，设置session
		session.setAttribute("loginInfo", loginInfo);

		String path = req.getContextPath();
		resp.sendRedirect(path + url);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		this.doGet(req, resp);
	}
}
