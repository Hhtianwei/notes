package com.tim.sso.filter;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tim.http.HttpClient;
import com.tim.sso.login.LoginInfo;


public class SessionFilter implements Filter
{

	private String[] urls;

	public void destroy()
	{

	}

	public void doFilter(ServletRequest servletrequest, ServletResponse servletresponse, FilterChain filterchain)
			throws IOException, ServletException
	{
		HttpServletRequest request = (HttpServletRequest) servletrequest;
		HttpServletResponse response = (HttpServletResponse) servletresponse;
		HttpSession session = request.getSession();
		System.out.println("SessionFilter sessioniD:" + session.getId());
		LoginInfo loginInfo = (LoginInfo) session.getAttribute("loginInfo");
		String servletPath = request.getServletPath();
		String token = request.getParameter("token");
		String name = request.getParameter("name");
		if (urls == null || urls.length == 0)
		{
			if (loginInfo == null && !checkToken(request))
			{
				response.sendRedirect("http://localhost:8082/sso_server/ssoLogin");
				return;
			}
			else
			{
				loginInfo = new LoginInfo();
				loginInfo.setLoginTime(new Date());
				loginInfo.setToken(token);
				loginInfo.setUserName(name);

				//sso 登录成功，设置session
				session.setAttribute("loginInfo", loginInfo);
			}
		}
		else
		{
			if (!hasExcludeURL(servletPath) && loginInfo == null && !checkToken(request))
			{
				response.sendRedirect("http://localhost:8082/sso_server/ssoLogin?url=" + servletPath);
				return;
			}
			else
			{
				loginInfo = new LoginInfo();
				loginInfo.setLoginTime(new Date());
				loginInfo.setToken(token);
				loginInfo.setUserName(name);

				//sso 登录成功，设置session
				session.setAttribute("loginInfo", loginInfo);
			}
		}
		filterchain.doFilter(servletrequest, servletresponse);
	}

	private boolean hasExcludeURL(String url)
	{
		if (urls == null || urls.length == 0)
		{
			return false;
		}
		boolean flag = false;
		for (String u : urls)
		{
			if (url.contains(u))
			{
				flag = true;
				break;
			}
		}
		return flag;
	}

	public void init(FilterConfig filterconfig) throws ServletException
	{
		String excludeUrls = filterconfig.getInitParameter("exclude");
		this.urls = excludeUrls.split(",");
	}

	private boolean checkToken(HttpServletRequest request)
	{
		String token = request.getParameter("token");
		String name = request.getParameter("name");
		if (token == null || "".equals(token) || name == null || "".equals(name))
		{
			return false;
		}
		String url = "http://localhost:8082/sso_server/ssoCheck";
		HttpClient client = new HttpClient(url, 30000, 30000);
		Map<String, String> loginData = new HashMap<String, String>();
		loginData.put("name", name);
		loginData.put("token", token);
		try
		{
			client.send(loginData, "utf-8");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		String result = client.getResult();
		System.out.println("result:" + result);
		return Boolean.valueOf(result);
	}

}
