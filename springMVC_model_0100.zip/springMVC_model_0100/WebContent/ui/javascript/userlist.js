$(function(){
	console.info("--------userList js--------------");
});